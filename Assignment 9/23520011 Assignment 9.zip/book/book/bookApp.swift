//
//  bookApp.swift
//  book
//
//  Created by Apple Lab 16 on 24/03/25.
//

import SwiftUI

@main
struct bookApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
